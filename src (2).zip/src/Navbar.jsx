// import React from "react";
// import { NavLink } from "react-router-dom";

// const Navbar = () => {
//   return (
    
//         <div className="font-bold   ">
//           <a>Navbar</a>
//           <div className="flex">
//             <a href="/">Home</a>
//             <div><NavLink to="/create">add posts</NavLink></div>
            
//           </div>
//         </div>
//       </article>
//     </section>
//   );
// };

// export default Navbar;
